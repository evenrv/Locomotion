package com.example.Loomo;

import android.content.Context;
import android.view.View;

import com.example.locomotion.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.segway.robot.algo.Pose2D;
import com.segway.robot.sdk.base.bind.ServiceBinder;
import com.segway.robot.sdk.locomotion.sbv.Base;
import com.segway.robot.sdk.perception.sensor.Sensor;
import com.segway.robot.sdk.perception.sensor.SensorData;

import java.util.ArrayList;
import java.util.Arrays;

//Class to add checkpoints for Loomo
public class AddCheckpoints {
    Base mBase;
    Point_converter converter = new Point_converter();
    double[][] output;
    public double[] coordx;
    public double[] coordy;

    private boolean driving;
    private boolean obstacle;
    float sum_x = 0;
    float sum_y = 0;



    //The function that adds checkpoints for Loomo
    public void add(final Double[][] coords, ArrayList<Integer> indexes, Context context) {

        Point_converter point_converter = new Point_converter();

        // double[][ coordinates = new double[coords.length][2];
        double[][] routeArr = point_converter.convert(coords);

        System.out.println(routeArr[0].length + ",coords=  " + coords.length);

        //Activating mBase to control Loomo

        Sensor mSensor;

        mSensor = Sensor.getInstance();
        mSensor.bindService(context, new ServiceBinder.BindStateListener() {
            @Override
            public void onBind() {

            }

            @Override
            public void onUnbind(String reason) {

            }
        });


              /*  mBase.setControlMode(Base.CONTROL_MODE_NAVIGATION);
                mBase.cleanOriginalPoint();
                Pose2D pose2D = mBase.getOdometryPose(-1);
                mBase.setOriginalPoint(pose2D);

                SensorData mPose2DData = mSensor.querySensorData(Arrays.asList(Sensor.POSE_2D)).get(0);
                Pose2D pose2D1 = mSensor.sensorDataToPose2D(mPose2DData);
                float mLinearVelocity;
                mLinearVelocity = pose2D1.getLinearVelocity();

                SensorData mUltrasonicData = mSensor.querySensorData(Arrays.asList(Sensor.ULTRASONIC_BODY)).get(0);
                float mUltrasonicDistance;
                mUltrasonicDistance = mUltrasonicData.getIntData()[0];
                */

                //Setting Loomos speed
              //  mBase.setLinearVelocity(100f);

                //Creating checkpoints
                addSensor(routeArr, 0, 0);   //addSensor(coordinates, mLinearVelocity, mUltrasonicDistance);



            }
      public  void addSensor(double[][] routeArr, float LinearVelocity, float mUltraSonicDistance){
            SystemTimer systemTimer = new SystemTimer();
            //Iterating through both coordinate-lists and adding one checkpoint each iteration.
            //"driving" is set to true each iteration
            for (int i = 0; i < routeArr[0].length; i++) {
                sum_x += routeArr[1][i];
                sum_y += routeArr[0][i];
//                mBase.addCheckPoint(sum_x, sum_y);
                boolean driving = true;
                // a checkpoint is created.

                System.out.println("NewCheckPoint = "+ sum_x + ", " + sum_y);

                //While "driving" is true, check if
                //linear velocity < 0.1.
                // If true, then driving is false.

                    if ((LinearVelocity > 0.05)) {
                        driving = false;

                    } else driving = true;
                     systemTimer.takeTime(0.1);            // delay of _ms
            }
    }
}

