package com.example.Loomo;

import java.util.ArrayList;

public class ListToArray {

    public  Double[][] setDoubleArray(ArrayList<Double[]> arrayList){

        Double[][] a = new Double[arrayList.size()][2];

        for (int i = 0; i < arrayList.size(); i++) {
            a[i][0] =  arrayList.get(i)[0];
            a[i][1] = arrayList.get(i)[1];
        }
        return a;
    }

}
