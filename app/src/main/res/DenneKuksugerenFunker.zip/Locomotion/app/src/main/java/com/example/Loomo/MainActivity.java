package com.example.Loomo;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.locomotion.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static String urlRute = "https://api.mazemap.com/routing/directions/?srid=4326&hc=true&sourcelat=58.3339659&sourcelon=8.577406&targetlat=58.334395&targetlon=8.577172&sourcez=1&targetz=4&lang=en&distanceunitstype=metric&mode=PEDESTRIAN";
    private static String urlPath = "https://api.mazemap.com/routing/path/?srid=4326&hc=true&sourcelat=58.3339659&sourcelon=8.577406&targetlat=58.334395&targetlon=8.577172&sourcez=1&targetz=4&lang=en&distanceunitstype=metric&mode=PEDESTRIAN";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new MyTask().execute();                                     // When button is pushed, My-task-class will run,
                String abc= "Parse Succesfull";                                          // the route is then parsed to a doubleArr of coordinates
                System.out.println("Parsed Succesfylly");

                Snackbar.make(view, abc, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                long elapsedTime = 0;
                SystemTimer systemTimer = new SystemTimer();                // new instance of SystemTimer-class
                systemTimer.takeTime(1000);                        // initiates new instance with timeLimit of 1000 ms

                setContentView(R.layout.after_parse);                              // new frontend-interface is downloaded
            }
        }); */

    }


    private class MyTask extends AsyncTask<URL, Void, PathInfo> {

        @Override
        protected PathInfo doInBackground(URL... urls) {
            JSONObject jsonObjectPath = null;
            PathInfo pathInfo = new PathInfo();
            JSONPath jsonPath = new JSONPath();
            try {
                ParseJSON parseJSON = new ParseJSON();
                            // instanse av JsonParseRoute-klassen.
                // json_Object = parseJSON.readJsonFromUrl(urlRute);                     // parses Route-data from given URL
                jsonObjectPath = parseJSON.readJsonFromUrl(urlPath);
                pathInfo =  jsonPath.pathData(jsonObjectPath);

            } catch (JSONException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
           //  json1.sjekkHeis();                                                 // sjekker om
            return pathInfo;
        }

        protected void onPostExecute(PathInfo pathInfo) {                        // parsing av data har allerede skjedd, ved
            ArrayList<Double[]> a = (pathInfo.coordinateArray);
            ArrayList<Integer> b = (pathInfo.flagIndexes);
            driveLoomo(a,b);                                                     // få til en onClick for å kjøre

        }
    }

    public  void driveLoomo(final ArrayList<Double[]> checkPoints,final ArrayList<Integer> index){  // takes in ArrayList of coordinates and indexes of Elevator in as parameters

        FloatingActionButton fab3 = findViewById(R.id.navigate);
        fab3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    String abc= "Start Driving";                                          // the route is then parsed to a doubleArr of coordinates
                    System.out.println("Starts to drive!");
                    Snackbar.make(v, abc, Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                    for (int i = 0; i< checkPoints.size(); i++){
                        Double[] arr =  checkPoints.get(i);
                        System.out.println(arr[0] + ", " + arr[1]);
                    }
                    for( int j = 0; j<index.size(); j++){
                        System.out.println(index.get(j));
                    }
            }
        });


    }

}






