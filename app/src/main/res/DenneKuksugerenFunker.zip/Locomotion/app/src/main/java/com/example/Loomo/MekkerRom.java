package com.example.Loomo;

import java.io.IOException;
import java.io.InputStream;

public class MekkerRom {
    public Find_Room findroom = new Find_Room();

    public String[][] returnerRom(InputStream input){
         Create_Rooms createrooms = new Create_Rooms();
        String[][] Room = new String[0][];
         String[] RoomID;
         String[] RoomNumber;


        //When the app is created, rooms.txt is opened

        try {
            Room = createrooms.createarrays(input);
            RoomID = Room[0];
            RoomNumber = Room[1];

        } catch (
                IOException e) {
            e.printStackTrace();
        }

        return Room;
    }

}



