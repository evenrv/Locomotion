package com.example.Loomo;

public class Find_Room {


    String TheRoom;


    public String FindRoomID(String[] RoomID, String[] RoomNumber, String message) {

        //Bytter A2 046 ut med stringen message
        //public String returnroomID()

        for (int ii = 0; ii < RoomID.length; ii++) {

            if (RoomNumber[ii].contains(message)) {
                TheRoom = RoomID[ii];
            }


        }
        return TheRoom;
    }
}
