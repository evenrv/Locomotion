package com.example.Loomo;

public class SystemTimer {
    public void takeTime(double timeLimit){
        long startTime = System.currentTimeMillis();
        long elapsedTime = 0;
        while(elapsedTime<timeLimit){
            elapsedTime = System.currentTimeMillis() - startTime;
        }
    }

}
