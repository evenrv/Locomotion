package com.example.Loomo;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.locomotion.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.segway.robot.sdk.base.bind.ServiceBinder;
import com.segway.robot.sdk.locomotion.sbv.Base;
import com.segway.robot.sdk.perception.sensor.Sensor;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import java.util.ArrayList;



public class MainKopi extends AppCompatActivity {
    ListInteger listInteger = new ListInteger();

    // Creating objects to control the base and the sensors of Loomo. Creates checkpoint object to
    // add checkpoints later, and new_url object to create an  URL.



    //Creating an object called new_url to create url when parse-button is pressed
    //NewURL will be set as the output of the make_url()-function
    UrlMaker urlMaker = new UrlMaker();
    // Creating a converter object to convert the global coordinates in degrees
    // to local coordinates in metres. "Output" is an array with
    // two elements: x-coordinates and y-coordinates



    //Creating a createrooms object to create two arrays from rooms.txt. The first array contains
    //all room numbers and the second contains all IDs for the room numbers.



    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        //When the app is created, rooms.txt is opened
        InputStream input;
        input = getResources().openRawResource(R.raw.rooms);
        MekkerRom mekkerRom = new MekkerRom();
        final String[][]Room = mekkerRom.returnerRom(input);        */


        FloatingActionButton parsePath = findViewById(R.id.parsePath);
        parsePath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                new MyTask().execute();                                      // When button is pushed, My-task-class will run,

                String abc = "Parse Succesfull";                           // the route is then parsed to a doubleArr of coordinates
                System.out.println("Parsed Succesfylly");

                Snackbar.make(view, abc, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                SystemTimer systemTimer = new SystemTimer();                // new instance of SystemTimer-class
                systemTimer.takeTime(1000);                        // initiates new instance with timeLimit of 1000 ms

                setContentView(R.layout.after_parse);                      // new screenlayout is uploaded
            }
        });


        //This function is called when the button is pressed. It fetches the written room number
        //in the text box and makes it a string. Then it iterates through a list
        /*
        FloatingActionButton navigate  = findViewById(R.id.navigate);
        navigate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] RoomID = Room[0];
                String[] RoomNumber = Room[1];

                //Fetching the rooms.txt document, and creating one array for all rooms and one array for
                    //all room IDs, with each ID having the same location in it's array as the corresponding
                    //room in the room array


                    TextView room = findViewById(R.id.editText);
                    String message = room.getText().toString();
                    Find_Room findroom = new Find_Room();
                    String TheRoom = findroom.FindRoomID(RoomID, RoomNumber, message);


                    System.out.println("your input:" + message);
                    System.out.println("Room ID" + TheRoom);

                    Snackbar.make(view, "Driving", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();

                }
            }); */
    }


        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected (MenuItem item){
            // Handle action bar item clicks here. The action bar will
            // automatically handle clicks on the Home/Up button, so long
            // as you specify a parent activity in AndroidManifest.xml.
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement
            if (id == R.id.action_settings) {
                return true;
            }

            return super.onOptionsItemSelected(item);
        }




    private class MyTask extends AsyncTask<URL, ListInteger, PathInfo> {

        @Override
        protected PathInfo doInBackground(URL... urls) {
            JSONObject jsonObjectPath = new JSONObject();
            JSONPath jsonPath = new JSONPath();
            PathInfo pathInfo = new PathInfo();
            ParseJSON parseJSON = new ParseJSON();
            // instanse av JsonParseRoute-klassen.
            // json_Object = parseJSON.readJsonFromUrl(urlRute);                     // parses Route-data from given URL
            try {
                String NewURL = urlMaker.makeUrl();
                System.out.println(NewURL);
                jsonObjectPath = parseJSON.readJsonFromUrl(NewURL);
                System.out.println(jsonObjectPath);                                     // denne parser riktig
                pathInfo = jsonPath.pathData(jsonObjectPath);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            //  json1.sjekkHeis();

            return pathInfo;
        }

        protected void onPostExecute(PathInfo pathInfo) {

            ArrayList<Double[]> a = (pathInfo.coordinateArray);
            ArrayList<Integer> b = (pathInfo.flagIndexes);


            listInteger.coorArray=a;
            listInteger.indexes=b;
            System.out.println("Ok");
            //sjekker om
            for(int i = 0; i < listInteger.coorArray.size(); i++){
                System.out.println(listInteger.coorArray.get(i)[0]);

            }
            final Context context = getApplicationContext();
            kjorLoomo(a,b, context);
        }
    }

        public void kjorLoomo (ArrayList<Double[]> checkPoints, final ArrayList<Integer> index , final Context context)
        {  // takes in ArrayList of coordinates and indexes of Elevator in as parameters

            ListToArray listToArray = new ListToArray();
            System.out.println(checkPoints.size());                                       // ok hittil

            final Double[][] b =  listToArray.setDoubleArray(checkPoints);



            System.out.println( "Lengde b = " + b.length);
            FloatingActionButton navigate  = findViewById(R.id.navigate);
            navigate.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                   AddCheckpoints addCheckpoints = new AddCheckpoints();
                    addCheckpoints.add( b, index ,context);                            // få a, b fra AsyncTask

                    String abc = "Start Driving";                                          // the route is then parsed to a doubleArr of coordinates
                    System.out.println("Starts to drive!");
                    Snackbar.make(view, abc, Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();

                    for (int j = 0; j < index.size(); j++) {
                        System.out.println(index.get(j));
                    }
                    Snackbar.make(view, "Driving", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            });
        }

}


