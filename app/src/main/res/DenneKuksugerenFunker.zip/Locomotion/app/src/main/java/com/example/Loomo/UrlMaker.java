package com.example.Loomo;

public class UrlMaker {


    /* URL_template = "https://api.mazemap.com/routing/path/?srid=4326&hc=true&sourcelat<FLOAT>=&sourcelon=<FLOAT>&targetlat=<FLOAT>&targetlon=<FLOAT>&sourcez=<INT>&targetz=<INT>&lang=en&distanceunitstype=metric&mode=PEDESTRIAN"; */

    private double lat1 = 58.3339659;
    private double lon1 = 8.577406;
    private double lat2 = 58.334395;
    private double lon2 = 8.577172;
    private int z1 = 1;
    private int z2 = 4;



    public String makeUrl() {

       String newURL = String.format("https://api.mazemap.com/routing/path/?srid=4326&hc=true&sourcelat=%s&sourcelon=%s&targetlat=%s&targetlon=%s&sourcez=%s&targetz=%s&lang=en&distanceunitstype=metric&mode=PEDESTRIAN", lat1,lon1,lat2,lon2,z1,z2);

       // System.out.println(newURL);
        String urlPath = "https://api.mazemap.com/routing/path/?srid=4326&hc=true&sourcelat=58.3339659&sourcelon=8.577406&targetlat=58.334395&targetlon=8.577172&sourcez=1&targetz=4&lang=en&distanceunitstype=metric&mode=PEDESTRIAN";

        return urlPath;

    }
}


