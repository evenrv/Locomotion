package com.example.Loomo;

public class Point_converter {

    final double grad = 111319.99;






    //Converting global coordinates in degrees to global coordinates in metres
    //by multiplying every element in the list by grad = 111319.99


    public double[][] convert(Double[][] input) {
         double[] coordx = new double[input.length];
         double[] coordy = new double[input.length];


        for (int i = 0; i < input.length; i++) {
            coordx[i] = input[i][0] * grad;
            coordy[i] = input[i][1] * grad;
        }

            double[] rutex = new double[coordx.length - 1];
            double[] rutey = new double[coordy.length - 1];


            //Creating a new list with local variables from Loomos standpoint.
            //Next point minus current point gives us the distance from Loomo, and acts like points to
            //Loomos coordinate-systems.
            for (int i = 0; i < coordx.length - 1; i++) {

                rutex[i] = coordx[i + 1] - coordx[i];
                rutey[i] = coordy[i + 1] - coordy[i];
            }


            //The fuinction returns a list called output, which is an array containing the two lists
            //rutex and rutey.
            double[][] output = {rutex, rutey};
            return output;
        }
}

