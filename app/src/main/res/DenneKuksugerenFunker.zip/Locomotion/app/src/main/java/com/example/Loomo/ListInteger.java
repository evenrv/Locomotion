package com.example.Loomo;

import java.util.ArrayList;

public class ListInteger  {

    static ArrayList<Integer> indexes = new ArrayList<>();
    static  ArrayList<Double[]> coorArray = new ArrayList<>();

}