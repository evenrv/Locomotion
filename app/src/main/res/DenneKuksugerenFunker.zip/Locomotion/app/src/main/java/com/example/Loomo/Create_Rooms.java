package com.example.Loomo;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;



public class Create_Rooms {

    public String[][] createarrays(InputStream input) throws IOException {



        BufferedReader buffer = new BufferedReader(new InputStreamReader(input));

        String line = buffer.readLine();
        StringBuilder stringbuilder = new StringBuilder();

        while (line != null) {
            stringbuilder.append(line).append("");
            line = buffer.readLine();


        }


        String room = stringbuilder.toString();


        room.split(",");
        String[] room2 = room.split(",");


        String[] RoomNumber = new String[room2.length / 2];
        String[] RoomID = new String[room2.length / 2];
        for (int i = 0; i < 1007; i++) {
            RoomID[i] = room2[2 * i];
            RoomNumber[i] = room2[2 * i + 1];
        }

        String[][] Room = {RoomID, RoomNumber};
        return Room;
    }
}
