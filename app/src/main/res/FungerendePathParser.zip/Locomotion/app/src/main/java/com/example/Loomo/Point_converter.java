package com.example.Loomo;

public class Point_converter {

    final double grad = 111319.99;





    public double[] input_x =
            {
                    0,
                    1,
                    1,
                    1.5,
                    1

                    /*8.576544501022067,
                    8.576596734438446,
                    8.576615204585941,*/
            };



    public double[] input_y =
            {
                    0,
                    0,
                    1,
                    0,
                    0.5

                  /*  58.33444281986944,
                    58.334236318323846,
                    58.33416329746184*/
            };



    public double[] coordx = new double[input_x.length];
    public double[] coordy = new double[input_y.length];

    public double[] rutex = new double[input_x.length-1];
    public double[] rutey = new double[input_y.length-1];



    //Converting global coordinates in degrees to global coordinates in metres
    //by multiplying every element in the list by grad = 111319.99


    public double[][] convert() {
       /* for (int i = 0; i < input_x.length; i++) {
            coordx[i] =  input_x[i] * grad;
            coordy[i] =  input_y[i] * grad;
        }*/



       //Creating a new list with local variables from Loomos standpoint.
        //Next point minus current point gives us the distance from Loomo, and acts like points to
        //Loomos coordinate-systems.
        for (int i = 0; i < coordx.length -1; i++){

            rutex[i] = input_x[i+1] - input_x[i];
            rutey[i] = input_y[i+1] - input_y[i];
        }


        //The fuinction returns a list called output, which is an array containing the two lists
        //rutex and rutey.
        double[][] output = {rutex, rutey};
        return output;
    }
}
