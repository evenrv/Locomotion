package com.example.Loomo;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.util.ArrayList;


public class JSONRoute {



    public static void jsonData(JSONObject jsonObject1) {

        try {
           JSONArray routeArray = (JSONArray) jsonObject1.get("routes");
            JSONObject routeObj = (JSONObject) routeArray.get(0);
            JSONArray legsArray =(JSONArray) routeObj.get("legs");     //
            JSONObject legsObj = (JSONObject) legsArray.get(0);        //
            JSONArray stepsArray = (JSONArray) legsObj.get("steps");   //
            for(int kk = 1; kk<stepsArray.size()-1; kk++ ){
                JSONObject stepsObj = (JSONObject) stepsArray.get(kk);       // temporary JSONObject, element nr kk of the stepsArray
                boolean  checkForElevator = (checkElevator(stepsObj.get("instruction"))); //Checks the instruction-string

                 JSONObject geometryObj =(JSONObject) (stepsObj.get("geometry"));     //
                ArrayList<Double[]> arrayListCoor = findCoordinateArray(geometryObj);
                loopStepsArr(arrayListCoor, checkForElevator);
            }
        } catch (NullPointerException e){
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static ArrayList<Double[]> findCoordinateArray(JSONObject geometryObj){      // takes JSONObject geometryObj as input

        JSONArray coordinateArr = (JSONArray) geometryObj.get("coordinates");           // finds JSONArray that contains "coordinates"-key
        ArrayList<Double[]> doubleArrCoor = new ArrayList<>();
        for(int ii = 0; ii < coordinateArr.size(); ii++) {                              // loops trough JSONArray coordinateArr
            JSONArray coordinatePair = (JSONArray) coordinateArr.get(ii);               // double-array of x-y-pair of coordinates
            Double[] x_y = new Double[2];
            for (int iii = 0; iii < coordinatePair.size(); iii++) {
                x_y[iii] = (Double) coordinatePair.get(iii);
            }
            doubleArrCoor.add(x_y);                                                     // sends double-array of x-y-pair of coordinates to Arratlist of double-array
        }
        return doubleArrCoor;
    }

    public static void loopStepsArr(ArrayList<Double[]> doubleArrCoor, boolean checkForElevator) {

        for(int mm = 0; mm<doubleArrCoor.size() ; mm++){
            double pos_x =  doubleArrCoor.get(mm)[0];                                  //
            double pos_y = doubleArrCoor.get(mm)[1];                                   //
            System.out.println(pos_x);
            System.out.println(pos_y);
           // mbase.addCheckPoint(pos_x, pos_y);
          //  driving = true;

               /* while( ciscoPosition.x != pos_x && ciscoPosition.y != pos_y ){     // legg til radius på antall meter ?
                    mbase.getCiscoPos();
                } */

          /*  if((checkForElevator==true) && (mm==doubleArrCoor.size()-1)){
                float avstand = 0 ;
                while( avstand < 0/* avstand til neste Posisjon  ){          // så lenge avstand er større enn satt grense
                 //   avstand = mbase.lesAvstand();
                }
                    // Legg in while-løkke her */
            }
     }


    public static boolean  checkElevator (Object object){
         String instruction =  object.toString();            // makes the object passed to string
        if (instruction.contains("elevator") && instruction.contains("should")){
            System.out.println("Elevator");
            return true;
        }
        else
            return false;
     }

}



