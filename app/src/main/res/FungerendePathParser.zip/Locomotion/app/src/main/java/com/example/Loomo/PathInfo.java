package com.example.Loomo;

import java.util.ArrayList;

public class PathInfo {

    static ArrayList<Integer> flagIndexes = new ArrayList<>();
    static  ArrayList<Double[]> coordinateArray = new ArrayList<>();

}
