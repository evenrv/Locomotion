package com.example.Loomo;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.stream.Stream;

public class Point extends ArrayList<Double> {

    public double x;
    public double y;
    // ublic double[] Str = {x,y};
    @NonNull
    @Override
    public Stream<Double> stream() {
        return null;
    }
}
