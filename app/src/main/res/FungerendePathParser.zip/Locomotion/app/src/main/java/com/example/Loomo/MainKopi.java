package com.example.Loomo;


import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.locomotion.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.segway.robot.algo.Pose2D;
import com.segway.robot.sdk.base.bind.ServiceBinder;
import com.segway.robot.sdk.locomotion.sbv.Base;
import com.segway.robot.sdk.perception.sensor.Sensor;
import com.segway.robot.sdk.perception.sensor.SensorData;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Arrays;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONException;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;



public class MainKopi extends AppCompatActivity {

    // Creating objects to control the base and the sensors of Loomo. Creates checkpoint object to
    // add checkpoints later, and new_url object to create an  URL.

    Base mBase;
    addcheckpoints checkpoint = new addcheckpoints();
    Sensor mSensor;

    //Creating an object called new_url to create url when parse-button is pressed
    //NewURL will be set as the output of the make_url()-function
    url_maker new_url = new url_maker();

    // Creating a converter object to convert the global coordinates in degrees
    // to local coordinates in metres. "Output" is an array with
    // two elements: x-coordinates and y-coordinates

    Point_converter converter = new Point_converter();
    double[][] output;
    public double[] coordx;
    public double[] coordy;


    //Creating a createrooms object to create two arrays from rooms.txt. The first array contains
    //all room numbers and the second contains all IDs for the room numbers.

    public Create_Rooms createrooms = new Create_Rooms();
    String[][] Room;
    public String[] RoomID;
    public String[] RoomNumber;

    public Find_Room findroom = new Find_Room();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String NewURL = new_url.make_url();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mBase = Base.getInstance();
        mBase.bindService(getApplicationContext(), new ServiceBinder.BindStateListener() {
            @Override
            public void onBind() {

            }

            @Override
            public void onUnbind(String reason) {

            }
        });



        //When the app is created, rooms.txt is opened
        InputStream input;
        input = getResources().openRawResource(R.raw.rooms);

        try {

            Room = createrooms.createarrays(input);

        } catch (IOException e) {
            e.printStackTrace();
        }

        RoomID = Room[0];
        RoomNumber = Room[1];


        mSensor = Sensor.getInstance();
        mSensor.bindService(getApplicationContext(), new ServiceBinder.BindStateListener() {
            @Override
            public void onBind() {

            }

            @Override
            public void onUnbind(String reason) {

            }
        });

        FloatingActionButton parsePath = findViewById(R.id.parsePath);
        parsePath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String NewURL = new_url.make_url();

                new MyTask().execute();                                                     // When button is pushed, My-task-class will run,

                String abc = "Parse Succesfull";                                          // the route is then parsed to a doubleArr of coordinates
                System.out.println("Parsed Succesfylly");

                Snackbar.make(view, abc, Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                long elapsedTime = 0;
                SystemTimer systemTimer = new SystemTimer();                // new instance of SystemTimer-class
                systemTimer.takeTime(1000);                        // initiates new instance with timeLimit of 1000 ms

                setContentView(R.layout.after_parse);                              // new frontend-interface is downloaded
            }
        });



        FloatingActionButton getroute  = findViewById(R.id.getroute);
        getroute.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v1) {

                //  myTask.onPostExecute(jsonObject);

                //Converting the global points to local points
                output =  converter.convert();
                coordx = output[0];
                coordy = output[1];


            }
        });




        /*
        FloatingActionButton navigate  = findViewById(R.id.navigate);
        navigate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Activating mBase to control Loomo

                mBase.setControlMode(Base.CONTROL_MODE_NAVIGATION);
                mBase.cleanOriginalPoint();
                Pose2D pose2D = mBase.getOdometryPose(-1);
                mBase.setOriginalPoint(pose2D);

                SensorData mPose2DData = mSensor.querySensorData(Arrays.asList(Sensor.POSE_2D)).get(0);
                Pose2D pose2D1 = mSensor.sensorDataToPose2D(mPose2DData);
                float mLinearVelocity;
                mLinearVelocity = pose2D1.getLinearVelocity();

                SensorData mUltrasonicData = mSensor.querySensorData(Arrays.asList(Sensor.ULTRASONIC_BODY)).get(0);
                float mUltrasonicDistance;
                mUltrasonicDistance = mUltrasonicData.getIntData()[0];


                //Setting Loomos speed
                mBase.setLinearVelocity(100f);

                //Creating checkpoints
                checkpoint.add(mLinearVelocity, mUltrasonicDistance);


                Snackbar.make(view, "Driving", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        }); */
    }




        //This function is called when the button is pressed. It fetches the written room number
        //in the text box and makes it a string. Then it iterates through a list

        public void getroom (View V){


            //Fetching the rooms.txt document, and creating one array for all rooms and one array for
            //all room IDs, with each ID having the same location in it's array as the corresponding
            //room in the room array


            TextView room = findViewById(R.id.editText);
            String message = room.getText().toString();

            String TheRoom = findroom.FindRoomID(RoomID, RoomNumber, message);


            System.out.println("your input:" + message);
            System.out.println("The ID of your Room:" + TheRoom);


        }


        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.menu_main, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected (MenuItem item){
            // Handle action bar item clicks here. The action bar will
            // automatically handle clicks on the Home/Up button, so long
            // as you specify a parent activity in AndroidManifest.xml.
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement
            if (id == R.id.action_settings) {
                return true;
            }

            return super.onOptionsItemSelected(item);
        }


        //Class to add checkpoints for Loomo
        private class addcheckpoints {

            private boolean driving;
            private boolean obstacle;
            float sum_x;
            float sum_y;


            //The function that adds checkpoints for Loomo
            private void add(float LinearVelocity, float mUltrasonicDistance) {

                obstacle = false;


                //Iterating through both coordinate-lists and adding one checkpoint each iteration.
                //"driving" is set to true each iteration
                for (int i = 0; i < coordx.length; ++i) {
                    sum_x += coordx[i];
                    sum_y += coordy[i];
                    mBase.addCheckPoint(sum_x, sum_y);
                    driving = true;
                    // a checkpoint is created.


                    //While "driving" is true, check if
                    //linear velocity < 0.1.
                    // If true, then driving is false.
                    while (driving) {
                        if ((LinearVelocity < 0.05)) {

                            driving = false;

                        } else driving = true;

                    }
                }
            }
        }



    private class MyTask extends AsyncTask<URL, Void, PathInfo> {

        @Override
        protected PathInfo doInBackground(URL... urls) {
            JSONObject jsonObjectPath = null;
            PathInfo pathInfo = new PathInfo();
            JSONPath jsonPath = new JSONPath();
            ParseJSON parseJSON = new ParseJSON();
            // instanse av JsonParseRoute-klassen.
            // json_Object = parseJSON.readJsonFromUrl(urlRute);                     // parses Route-data from given URL
            try {
                String NewURL = new_url.make_url();

                jsonObjectPath = parseJSON.readJsonFromUrl(NewURL);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
            pathInfo = jsonPath.pathData(jsonObjectPath);

            //  json1.sjekkHeis();                                                 // sjekker om
            return pathInfo;
        }

        protected void onPostExecute(PathInfo pathInfo) {                        // parsing av data har allerede skjedd, ved
            ArrayList<Double[]> a = (pathInfo.coordinateArray);
            ArrayList<Integer> b = (pathInfo.flagIndexes);
            driveLoomo(a, b);                                                     // få til en onClick for å kjøre

        }
    }

        public void driveLoomo ( final ArrayList<Double[]> checkPoints, final ArrayList<Integer> index)
        {  // takes in ArrayList of coordinates and indexes of Elevator in as parameters

            FloatingActionButton fab3 = findViewById(R.id.fab3);
            fab3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String abc = "Start Driving";                                          // the route is then parsed to a doubleArr of coordinates
                    System.out.println("Starts to drive!");
                    Snackbar.make(v, abc, Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                    for (int i = 0; i < checkPoints.size(); i++) {
                        Double[] arr = checkPoints.get(i);
                        System.out.println(arr[0] + ", " + arr[1]);
                    }
                    for (int j = 0; j < index.size(); j++) {
                        System.out.println(index.get(j));
                    }
                }
            });
        }
}


